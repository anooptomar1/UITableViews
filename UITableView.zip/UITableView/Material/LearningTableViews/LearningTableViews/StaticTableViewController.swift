//
//  StaticTableViewController.swift
//  LearningTableViews
//
//  Created by Anoop tomar on 2/10/18.
//  Copyright © 2018 Devtechie. All rights reserved.
//

import UIKit

class StaticTableViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    var data: [FruitsNVeggies] = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.data = FruitsNVeggies.FoodItems()
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "details"
        {
            let destinationVC = segue.destination as! DetailsTableViewController
            destinationVC.food = sender as? Food
        }
    }
}

extension StaticTableViewController: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return data.count
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data[section].foodItems.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        let food = data[indexPath.section].foodItems[indexPath.row]
        cell?.textLabel?.text = food.title
        cell?.detailTextLabel?.text = food.subtitle
        cell?.imageView?.image = food.image
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.performSegue(withIdentifier: "details", sender: data[indexPath.section].foodItems[indexPath.row])
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return data[section].name
    }
}
