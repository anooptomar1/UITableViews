//
//  SearchTableViewViewController.swift
//  LearningTableViews
//
//  Created by Anoop tomar on 2/10/18.
//  Copyright © 2018 Devtechie. All rights reserved.
//

import UIKit

class SearchTableViewViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var searchBar: UISearchBar!
    
    var data: [Food] = []
    var filterData: [Food] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.tableView.delegate = self
        self.tableView.dataSource = self
        
        for item in FruitsNVeggies.FoodItems() {
            data.append(contentsOf: item.foodItems)
        }
        
        filterData = data
        
        self.searchBar.delegate = self
    }
}

extension SearchTableViewViewController: UISearchBarDelegate {
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        guard !searchText.isEmpty else {
            filterData = data
            tableView.reloadData()
            return
        }
        
        filterData = data.filter({ (food) -> Bool in
            return food.title.contains(searchText)
        })
        tableView.reloadData()
    }
}

extension SearchTableViewViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filterData.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        cell?.textLabel?.text = filterData[indexPath.row].title
        cell?.detailTextLabel?.text = filterData[indexPath.row].subtitle
        cell?.imageView?.image = filterData[indexPath.row].image
        return cell!
    }
}
