//
//  ProgrammaticTableViewController.swift
//  LearningTableViews
//
//  Created by Anoop tomar on 2/7/18.
//  Copyright © 2018 Devtechie. All rights reserved.
//

import UIKit

class ProgrammaticTableViewController: UIViewController {
    
    lazy var tableView: UITableView = {
        let v = UITableView()
        v.dataSource = self
        v.delegate = self
        v.translatesAutoresizingMaskIntoConstraints = false
        v.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        return v
    }()
    
    var data: [Food] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        
        for item in FruitsNVeggies.FoodItems() {
            data.append(contentsOf: item.foodItems)
        }
        self.title = "Programmatic Tableview Controller"
        self.view.addSubview(tableView)
        NSLayoutConstraint.activate([
            tableView.leadingAnchor.constraint(equalTo: self.view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: self.view.trailingAnchor),
            tableView.topAnchor.constraint(equalTo: self.view.topAnchor),
            tableView.bottomAnchor.constraint(equalTo: self.view.bottomAnchor)
        ])
        
    }

}

extension ProgrammaticTableViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        let item = data[indexPath.row]
        cell?.textLabel?.text = item.title
        cell?.detailTextLabel?.text = item.subtitle
        cell?.imageView?.image = item.image
        return cell!
    }
}














