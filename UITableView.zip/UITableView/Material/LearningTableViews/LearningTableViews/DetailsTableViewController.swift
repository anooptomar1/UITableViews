//
//  DetailsTableViewController.swift
//  LearningTableViews
//
//  Created by Anoop tomar on 2/10/18.
//  Copyright © 2018 Devtechie. All rights reserved.
//

import UIKit

class DetailsTableViewController: UITableViewController {

    var food: Food?
    
    @IBOutlet weak var imageV: UIImageView!
    @IBOutlet weak var titleText: UILabel!
    @IBOutlet weak var subtitleText: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        imageV.image = food?.fullImage
        titleText.text = food?.title
        subtitleText.text = food?.subtitle
    }

}
