//
//  TableViewWithEditViewController.swift
//  LearningTableViews
//
//  Created by Anoop tomar on 2/7/18.
//  Copyright © 2018 Devtechie. All rights reserved.
//

import UIKit

class TableViewWithEditViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    
    var data: [FruitsNVeggies] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.delegate = self
        tableView.dataSource = self
        
        self.data = FruitsNVeggies.FoodItems()
        
        navigationItem.rightBarButtonItem = editButtonItem
    }
}

extension TableViewWithEditViewController: UITableViewDataSource, UITableViewDelegate {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return data.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data[section].foodItems.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        let item = data[indexPath.section].foodItems[indexPath.row]
        cell?.textLabel?.text = item.title
        cell?.detailTextLabel?.text = item.subtitle
        cell?.imageView?.image = item.image
        return cell!
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return data[section].name
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            data[indexPath.section].foodItems.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .automatic)
        }
    }
    
    override func setEditing(_ editing: Bool, animated: Bool) {
        super.setEditing(editing, animated: animated)
        
        if editing {
            self.tableView.setEditing(true, animated: animated)
        } else {
            self.tableView.setEditing(false, animated: animated)
        }
    }
}










