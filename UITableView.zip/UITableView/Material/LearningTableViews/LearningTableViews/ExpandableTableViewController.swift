//
//  ExpandableTableViewController.swift
//  LearningTableViews
//
//  Created by Anoop tomar on 3/22/18.
//  Copyright © 2018 Devtechie. All rights reserved.
//

import UIKit

class ExpandableTableViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    var data: [FruitsNVeggies] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.data = FruitsNVeggies.FoodItems()
        
        // hide table view footer
        tableView.tableFooterView = UIView()
    }
    
    @objc func handleSectionToggle(sender: UIButton) {
        data[sender.tag].isExpanded = !data[sender.tag].isExpanded
        tableView.reloadSections([sender.tag], with: UITableViewRowAnimation.automatic)
    }
}

extension ExpandableTableViewController: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return data.count
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if data[section].isExpanded {
            return data[section].foodItems.count
        }
        return 0
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        let foodItem = data[indexPath.section].foodItems[indexPath.row]
        cell?.textLabel?.text = foodItem.title
        cell?.detailTextLabel?.text = foodItem.subtitle
        cell?.imageView?.image = foodItem.image
        return cell!
    }
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return data[section].name
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 36
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let label = UILabel()
        label.text = "    \(data[section].name)"
        label.textColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        label.backgroundColor = #colorLiteral(red: 0.3649819457, green: 0.4806271503, blue: 1, alpha: 0.6666317114)
        
        let button = UIButton(type: UIButtonType.system)
        button.backgroundColor = #colorLiteral(red: 0.3649819457, green: 0.4806271503, blue: 1, alpha: 0.6666317114)
        button.setTitleColor(#colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0), for: UIControlState.normal)
        if data[section].isExpanded {
            button.setTitle("Hide    ", for: UIControlState.normal)
        } else {
            button.setTitle("Show    ", for: UIControlState.normal)
        }
        button.addTarget(self, action: #selector(handleSectionToggle(sender:)), for: UIControlEvents.touchUpInside)
        button.tag = section
        
        let stackView = UIStackView(arrangedSubviews: [label, button])
        stackView.alignment = .fill
        stackView.axis = .horizontal
        stackView.distribution = .fill
        
        return stackView
    }
}












