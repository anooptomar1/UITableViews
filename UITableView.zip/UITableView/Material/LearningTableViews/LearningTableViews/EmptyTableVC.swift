//
//  EmptyTableVC.swift
//  LearningTableViews
//
//  Created by Anoop tomar on 3/22/18.
//  Copyright © 2018 Devtechie. All rights reserved.
//

import UIKit

class EmptyTableVC: UIViewController {

    @IBOutlet weak var noContentView: UIView!
    @IBOutlet weak var tableView: UITableView!
    
    var data: [Food] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

        tableView.delegate = self
        tableView.dataSource = self
        
        tableView.backgroundView = noContentView
        tableView.tableFooterView = UIView()
        self.loadDataWithDelay()
    }

    func loadDataWithDelay() {
        DispatchQueue.global(qos: DispatchQoS.QoSClass.background).asyncAfter(deadline: .now() + .milliseconds(5000)) {
            for item in FruitsNVeggies.FoodItems() {
                self.data.append(contentsOf: item.foodItems)
            }
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
        }
    }
  
}
extension EmptyTableVC: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        let foodItem = data[indexPath.row]
        cell?.textLabel?.text = foodItem.title
        cell?.detailTextLabel?.text = foodItem.subtitle
        cell?.imageView?.image = foodItem.image
        return cell!
    }
}










