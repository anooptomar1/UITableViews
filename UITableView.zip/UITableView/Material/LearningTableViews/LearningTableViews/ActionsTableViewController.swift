//
//  ActionsTableViewController.swift
//  LearningTableViews
//
//  Created by Anoop tomar on 3/22/18.
//  Copyright © 2018 Devtechie. All rights reserved.
//

import UIKit

class ActionsTableViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    
    var data: [Food] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        
        for item in FruitsNVeggies.FoodItems() {
            data.append(contentsOf: item.foodItems)
        }
        
        tableView.delegate = self
        tableView.dataSource = self
        
        tableView.rowHeight = 100
    }
}

extension ActionsTableViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        let fruit = data[indexPath.row]
        cell?.textLabel?.text = fruit.title
        cell?.detailTextLabel?.text = fruit.subtitle
        cell?.imageView?.image = fruit.image
        return cell!
    }
    
    func tableView(_ tableView: UITableView, leadingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let archiveAction = UIContextualAction(style: UIContextualAction.Style.normal, title: "Archive") { (action, view, _) in
            print("User selected Archive")
        }
        let saveAction = UIContextualAction(style: UIContextualAction.Style.normal, title: "Save") { (action, view, _) in
            print("User selected Save")
        }
        
        archiveAction.backgroundColor = #colorLiteral(red: 0.3176470697, green: 0.07450980693, blue: 0.02745098062, alpha: 1)
        saveAction.backgroundColor = #colorLiteral(red: 0.1764705926, green: 0.4980392158, blue: 0.7568627596, alpha: 1)
        archiveAction.image = #imageLiteral(resourceName: "archive")
        saveAction.image = #imageLiteral(resourceName: "save")
        
        let config = UISwipeActionsConfiguration(actions: [archiveAction, saveAction])
        config.performsFirstActionWithFullSwipe = false
        return config
    }
    
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let infoAction = UIContextualAction(style: UIContextualAction.Style.normal, title: "Info") { (action, view, _) in
            print("User selected Info")
        }
        let deleteAction = UIContextualAction(style: UIContextualAction.Style.destructive, title: "Delete") { (action, view, _) in
            print("User selected Delete")
        }
        infoAction.backgroundColor = #colorLiteral(red: 0.2745098174, green: 0.4862745106, blue: 0.1411764771, alpha: 1)
        deleteAction.backgroundColor = #colorLiteral(red: 1, green: 0.1491314173, blue: 0, alpha: 1)
        
        infoAction.image = #imageLiteral(resourceName: "info")
        deleteAction.image = #imageLiteral(resourceName: "delete")
        let config = UISwipeActionsConfiguration(actions: [deleteAction, infoAction])
        config.performsFirstActionWithFullSwipe = false
        return config
    }
}
