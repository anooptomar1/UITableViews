//
//  TableViewWithRefreshVC.swift
//  LearningTableViews
//
//  Created by Anoop tomar on 3/22/18.
//  Copyright © 2018 Devtechie. All rights reserved.
//

import UIKit

class TableViewWithRefreshVC: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    var data: [FruitsNVeggies] = []
    
    var refreshControl: UIRefreshControl!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.data = FruitsNVeggies.FoodItems()
        
        refreshControl = UIRefreshControl()
        self.tableView.refreshControl = refreshControl
        refreshControl.addTarget(self, action: #selector(handleRefresh), for: UIControlEvents.valueChanged)
    }
    
    @objc func handleRefresh() {
        DispatchQueue.main.asyncAfter(deadline: .now() + .milliseconds(2000)) {
            self.refreshControl.endRefreshing()
            self.data[0].foodItems.append(Food(title: "Apple", subtitle: "Apples are high in fiber, vitamin C and various antioxidants.", image: #imageLiteral(resourceName: "apple_small.jpg"), fullImage: #imageLiteral(resourceName: "apple.jpg")))
            self.data[0].foodItems.append(Food(title: "Apricot", subtitle: "Apricots are packed with Vitamin A, which is also known as retinol.", image: #imageLiteral(resourceName: "appricot_small.jpg"), fullImage: #imageLiteral(resourceName: "appricot.jpg")))
            self.data[0].foodItems.append(Food(title: "Strawberry", subtitle: " Strawberry nutrients include vitamin C, folate, potassium, manganese, dietary fiber, and magnesium.", image: #imageLiteral(resourceName: "strawberry_small.jpg"), fullImage: #imageLiteral(resourceName: "strawberry.jpg")))
            self.tableView.reloadSections([0], with: UITableViewRowAnimation.automatic)
        }
    }
}

extension TableViewWithRefreshVC: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return data.count
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data[section].foodItems.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        let foodItem = data[indexPath.section].foodItems[indexPath.row]
        cell?.textLabel?.text = foodItem.title
        cell?.detailTextLabel?.text = foodItem.subtitle
        cell?.imageView?.image = foodItem.image
        return cell!
    }
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return data[section].name
    }
}
