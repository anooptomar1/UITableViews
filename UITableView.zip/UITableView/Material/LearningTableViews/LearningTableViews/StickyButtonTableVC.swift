//
//  StickyButtonTableVC.swift
//  LearningTableViews
//
//  Created by Anoop tomar on 3/22/18.
//  Copyright © 2018 Devtechie. All rights reserved.
//

import UIKit

class StickyButtonTableVC: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    
    var data: [Food] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        for item in FruitsNVeggies.FoodItems() {
            data.append(contentsOf: item.foodItems)
        }
        
        tableView.delegate = self
        tableView.dataSource = self
    }

  
    @IBAction func didTapOnAddButton(sender: UIButton) {
        print("User tapped on Add!")
    }
}

extension StickyButtonTableVC : UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        let foodItem = data[indexPath.row]
        cell?.textLabel?.text = foodItem.title
        cell?.detailTextLabel?.text = foodItem.subtitle
        cell?.imageView?.image = foodItem.image
        return cell!
    }
}
