//
//  Food.swift
//  SampleTableView
//
//  Created by Tomar, Anoop on 2/3/18.
//  Copyright © 2018 Tomar, Anoop. All rights reserved.
//

import UIKit
class Food {
    var title: String
    var subtitle: String
    var image: UIImage
    var fullImage: UIImage
    
    init(title: String, subtitle: String, image: UIImage, fullImage: UIImage) {
        
        self.title = title
        self.subtitle = subtitle
        self.image = image
        self.fullImage = fullImage
    }
}
