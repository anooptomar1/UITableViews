//
//  EmptyTableViewMessageVC.swift
//  SampleTableView
//
//  Created by Anoop tomar on 3/6/18.
//  Copyright © 2018 Tomar, Anoop. All rights reserved.
//

import UIKit

class EmptyTableViewMessageVC: UIViewController {

    @IBOutlet weak var noContentView: UIView!
   
    @IBOutlet weak var tableView: UITableView!
    
    var data: [Food] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.delegate = self
        tableView.dataSource = self
        
        tableView.backgroundView = noContentView
        tableView.tableFooterView = UIView()
        loadDataWithDelay()
    }
    
    func loadDataWithDelay() {
        DispatchQueue.global(qos: DispatchQoS.QoSClass.background).asyncAfter(deadline: .now() + .milliseconds(10000)) {
            for item in FruitsNVeggies.FoodItems() {
                self.data.append(contentsOf: item.foodItems)
            }
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
        }
    }
}

extension EmptyTableViewMessageVC: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        cell?.textLabel?.text = data[indexPath.row].title
        cell?.detailTextLabel?.text = data[indexPath.row].subtitle
        cell?.imageView?.image = data[indexPath.row].image
        return cell!
    }
}
