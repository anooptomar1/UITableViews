//
//  TableViewWithRefreshVC.swift
//  SampleTableView
//
//  Created by Anoop tomar on 3/4/18.
//  Copyright © 2018 Tomar, Anoop. All rights reserved.
//

import UIKit

class TableViewWithRefreshVC: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    var data: [FruitsNVeggies] = []

    // refresh control
    var refreshControl: UIRefreshControl!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.data = FruitsNVeggies.FoodItems()
        
        // refresh control
        refreshControl = UIRefreshControl()
        self.tableView.refreshControl = refreshControl
        refreshControl.addTarget(self, action: #selector(refreshContent), for: UIControlEvents.valueChanged)
    }
    
    @objc func refreshContent() {
        DispatchQueue.main.asyncAfter(deadline: .now() + .milliseconds(2000)) {
            self.refreshControl.endRefreshing()
            self.data[0].foodItems.append(Food(title: "Apple", subtitle: "Apples are high in fiber, vitamin C and various antioxidants.", image: #imageLiteral(resourceName: "apple_small.jpg"), fullImage: #imageLiteral(resourceName: "apple.jpg")))
            self.data[0].foodItems.append(Food(title: "Apricot", subtitle: "Apricots are packed with Vitamin A, which is also known as retinol.", image: #imageLiteral(resourceName: "appricot_small.jpg"), fullImage: #imageLiteral(resourceName: "appricot.jpg")))
            self.tableView.reloadSections([0], with: UITableViewRowAnimation.automatic)
        }
    }

}
extension TableViewWithRefreshVC: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return data.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data[section].foodItems.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        cell?.textLabel?.text = data[indexPath.section].foodItems[indexPath.row].title
        cell?.detailTextLabel?.text = data[indexPath.section].foodItems[indexPath.row].subtitle
        cell?.imageView?.image = data[indexPath.section].foodItems[indexPath.row].image
        return cell!
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return data[section].name
    }
}
