//
//  SearchTableViewController.swift
//  SampleTableView
//
//  Created by Anoop tomar on 2/10/18.
//  Copyright © 2018 Tomar, Anoop. All rights reserved.
//

import UIKit

class SearchTableViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var searchBar: UISearchBar!
    
    var data: [Food] = []
    var filteredData: [Food] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.delegate = self
        self.tableView.dataSource = self
        
        for item in FruitsNVeggies.FoodItems() {
            data.append(contentsOf: item.foodItems)
        }
        
        // search bar delegate
        self.searchBar.delegate = self
        
        filteredData = data
    }
}

extension SearchTableViewController: UISearchBarDelegate {
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        guard !searchText.isEmpty else {
            filteredData = data
            tableView.reloadData()
            return
        }
        
        filteredData = data.filter({ (food) -> Bool in
            return food.title.contains(searchText)
            
        })
        tableView.reloadData()
    }
}

extension SearchTableViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filteredData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        cell?.textLabel?.text = filteredData[indexPath.row].title
        cell?.detailTextLabel?.text = filteredData[indexPath.row].subtitle
        cell?.imageView?.image = filteredData[indexPath.row].image
        return cell!
    }
    
}
