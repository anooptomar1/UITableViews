//
//  SelfSizingViewController.swift
//  SampleTableView
//
//  Created by Anoop tomar on 2/10/18.
//  Copyright © 2018 Tomar, Anoop. All rights reserved.
//

import UIKit

class SelfSizingViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    var data: [FruitsNVeggies]!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        data = FruitsNVeggies.FoodItems()
        tableView.delegate = self
        tableView.dataSource = self
        tableView.estimatedRowHeight = 140
        tableView.rowHeight = UITableViewAutomaticDimension
    }
   
}

extension SelfSizingViewController: UITableViewDataSource, UITableViewDelegate {
    func numberOfSections(in tableView: UITableView) -> Int {
        return data.count
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data[section].foodItems.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! SelfSizingCell
        cell.setupCell(food: data[indexPath.section].foodItems[indexPath.row])
        return cell
    }
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return data[section].name
    }
}

class SelfSizingCell: UITableViewCell {
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var subtitleLabel: UILabel!
    @IBOutlet weak var imageV: UIImageView!
    
    
    
    func setupCell(food: Food) {
        self.titleLabel.text = food.title
        self.subtitleLabel.text = food.subtitle
        self.imageV.image = food.image
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        self.titleLabel.text = nil
        self.subtitleLabel.text = nil
        self.imageV.image = nil
    }
}
