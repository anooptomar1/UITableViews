//
//  ExpandableCollapsibleTableViewVC.swift
//  SampleTableView
//
//  Created by Anoop tomar on 3/4/18.
//  Copyright © 2018 Tomar, Anoop. All rights reserved.
//

import UIKit

class ExpandableCollapsibleTableViewVC: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    var data: [FruitsNVeggies] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.data = FruitsNVeggies.FoodItems()
        
        // collapsible
        tableView.tableFooterView = UIView()
    }

    // collapsible
    @objc func handleSectionToggle(sender: UIButton) {
        data[sender.tag].isExpanded = !data[sender.tag].isExpanded
        tableView.reloadSections([sender.tag], with: UITableViewRowAnimation.automatic)
        
    }
}

extension ExpandableCollapsibleTableViewVC: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return data.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // collapsible
        if data[section].isExpanded {
            return data[section].foodItems.count
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        cell?.textLabel?.text = data[indexPath.section].foodItems[indexPath.row].title
        cell?.detailTextLabel?.text = data[indexPath.section].foodItems[indexPath.row].subtitle
        cell?.imageView?.image = data[indexPath.section].foodItems[indexPath.row].image
        return cell!
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return data[section].name
    }
    
    // collapsible
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 36
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let label = UILabel()
        label.text = "    \(data[section].name)"
        label.textColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        label.backgroundColor = #colorLiteral(red: 0, green: 0.4784313725, blue: 1, alpha: 1)
        
        let button = UIButton(type: UIButtonType.system)
        if data[section].isExpanded {
            button.setTitle("Hide    ", for: UIControlState.normal)
        } else {
            button.setTitle("Show    ", for: UIControlState.normal)
        }
        button.backgroundColor = #colorLiteral(red: 0, green: 0.4784313725, blue: 1, alpha: 1)
        button.setTitleColor(#colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0), for: UIControlState.normal)
        button.titleLabel?.font = button.titleLabel?.font.withSize(16)
        button.addTarget(self, action: #selector(handleSectionToggle(sender:)), for: UIControlEvents.touchUpInside)
        button.tag = section
        
        let stackView = UIStackView(arrangedSubviews: [label, button])
        stackView.alignment = .fill
        stackView.axis = .horizontal
        stackView.distribution = .fill
        
        return stackView
    }
    
}
