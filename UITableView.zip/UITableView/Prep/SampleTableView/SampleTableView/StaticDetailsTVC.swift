//
//  StaticDetailsTVC.swift
//  SampleTableView
//
//  Created by Anoop tomar on 2/10/18.
//  Copyright © 2018 Tomar, Anoop. All rights reserved.
//

import UIKit

class StaticDetailsTVC: UITableViewController {

    var food: Food?
    
    @IBOutlet weak var titleText: UILabel!
    @IBOutlet weak var subtitleText: UILabel!
    @IBOutlet weak var imageV: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.titleText.text = food?.title
        self.subtitleText.text = food?.subtitle
        self.imageV.image = food?.fullImage
    }

}
