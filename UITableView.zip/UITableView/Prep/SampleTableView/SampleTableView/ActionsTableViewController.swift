//
//  ActionsTableViewController.swift
//  SampleTableView
//
//  Created by Anoop tomar on 3/2/18.
//  Copyright © 2018 Tomar, Anoop. All rights reserved.
//

import UIKit

class ActionsTableViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    
    var data: [Food] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        for item in FruitsNVeggies.FoodItems() {
            data.append(contentsOf: item.foodItems)
        }
        
        tableView.delegate = self
        tableView.dataSource = self
        
        // second part
        tableView.rowHeight = 100
    }


}

extension ActionsTableViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        cell?.textLabel?.text = data[indexPath.row].title
        cell?.detailTextLabel?.text = data[indexPath.row].subtitle
        cell?.imageView?.image = data[indexPath.row].image
        return cell!
    }
    
    func tableView(_ tableView: UITableView, leadingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let archiveAction = UIContextualAction(style: UIContextualAction.Style.normal, title: "Archive") { (action, view, _) in
            print("Archived Item")
        }
        let saveAction = UIContextualAction(style: UIContextualAction.Style.normal, title: "Save") { (action, view, _) in
            print("Saved Item")
        }
        
        // second part video
        archiveAction.backgroundColor = #colorLiteral(red: 0.7254902124, green: 0.4784313738, blue: 0.09803921729, alpha: 1)
        saveAction.backgroundColor = #colorLiteral(red: 0, green: 0.4784313725, blue: 1, alpha: 1)
        archiveAction.image = #imageLiteral(resourceName: "archive")
        saveAction.image = #imageLiteral(resourceName: "save")
        // second part end
        
        let config = UISwipeActionsConfiguration(actions: [archiveAction, saveAction])
        
        // second part
        config.performsFirstActionWithFullSwipe = false
        
        return config
    }
    
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let infoAction = UIContextualAction(style: UIContextualAction.Style.normal, title: "Info") { (action, view, _) in
            print("More info about the Item")
        }
        
        let deleteAction = UIContextualAction(style: UIContextualAction.Style.destructive, title: "Delete") { (action, view, _) in
            print("Delete item")
        }
        
        // second part video
        infoAction.backgroundColor = #colorLiteral(red: 0.4666666687, green: 0.7647058964, blue: 0.2666666806, alpha: 1)
        deleteAction.backgroundColor = #colorLiteral(red: 0.8745117188, green: 0.104846231, blue: 0, alpha: 1)
        infoAction.image = #imageLiteral(resourceName: "info")
        deleteAction.image = #imageLiteral(resourceName: "delete")
        // second part end
        
        let config = UISwipeActionsConfiguration(actions: [deleteAction, infoAction])
        
        // second part
        config.performsFirstActionWithFullSwipe = false
        
        
        return config
    }
}
