//
//  TableViewWithEditViewController.swift
//  SampleTableView
//
//  Created by Tomar, Anoop on 2/7/18.
//  Copyright © 2018 Tomar, Anoop. All rights reserved.
//

import UIKit

class TableViewWithEditViewController: UIViewController {
    @IBOutlet weak var tableView: UITableView!
    var data: [FruitsNVeggies] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.data = FruitsNVeggies.FoodItems()
        
        // add bar button item
        navigationItem.rightBarButtonItem = editButtonItem
    }
}
extension TableViewWithEditViewController: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return data.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data[section].foodItems.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        cell?.textLabel?.text = data[indexPath.section].foodItems[indexPath.row].title
        cell?.detailTextLabel?.text = data[indexPath.section].foodItems[indexPath.row].subtitle
        cell?.imageView?.image = data[indexPath.section].foodItems[indexPath.row].image
        return cell!
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return data[section].name
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            data[indexPath.section].foodItems.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .automatic)
        }
    }
    
    // editing button support
    override func setEditing(_ editing: Bool, animated: Bool) {
        super.setEditing(editing, animated: animated)
        if editing {
            self.tableView.setEditing(true, animated: animated)
        } else {
            self.tableView.setEditing(false, animated: animated)
        }
    }
}
