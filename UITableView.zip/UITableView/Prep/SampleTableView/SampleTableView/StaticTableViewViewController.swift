//
//  StaticTableViewViewController.swift
//  SampleTableView
//
//  Created by Anoop tomar on 2/10/18.
//  Copyright © 2018 Tomar, Anoop. All rights reserved.
//

import UIKit

class StaticTableViewViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    var data: [FruitsNVeggies] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.data = FruitsNVeggies.FoodItems()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "details" {
            let destVC = segue.destination as! StaticDetailsTVC
            destVC.food = sender as? Food
        }
    }
}
    
extension StaticTableViewViewController: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return data.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data[section].foodItems.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        cell?.textLabel?.text = data[indexPath.section].foodItems[indexPath.row].title
        cell?.detailTextLabel?.text = data[indexPath.section].foodItems[indexPath.row].subtitle
        cell?.imageView?.image = data[indexPath.section].foodItems[indexPath.row].image
        return cell!
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return data[section].name
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.performSegue(withIdentifier: "details", sender: data[indexPath.section].foodItems[indexPath.row])
    }
}

